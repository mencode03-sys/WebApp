<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Writing PHP Function which function calls</title>
</head>
<body>
     <?php
        function sayHello() {
            echo "Hello<br />";
        }
 
        $function_holder = "sayHello";
        $function_holder();
        sayHello();
    ?>
</body>
</html>