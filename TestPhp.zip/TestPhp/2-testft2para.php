<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Writing PHP Function with parameter</title>
</head>
<body>
    <H2>Fist time for PHP</H2>
    <?php
    Function addFunction($sum1, $sum2): void{
        $sum = $sum1 + $sum2;
        echo "Sum of the two numbers is : $sum";
    }
    addFunction(10,20);
    ?>
</body>
</html>