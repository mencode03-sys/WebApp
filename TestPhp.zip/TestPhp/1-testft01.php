<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Writing PHP Function</title>
</head>
<body>
    <H2>Fist time for PHP</H2>
    <?php
    Function WriteMessage(): void{
        echo "You are really a nice person, Have a nice time!";
    }
    WriteMessage();
    ?>
</body>
</html>