<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Passing Argment by Reference</title>
</head>
<body>
    <?php
    Function addive($sum) {
        $sum += 5;
    }
    Function addSix(&$sum){
        $sum += 6;
    }
    $orignum = 10;
    addFive( $orignum) ;
    echo "Original Value is $orignum<br />";

    addSix( $orignum);
    echo "Original Value is $orignum<br />";
    ?>
</body>
</html>